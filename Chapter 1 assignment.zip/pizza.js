

/*

This is my first js file
for chapter one assignment

*/

// Katherine Wright
// 9 JUN 2017

var vegetarian = "Lots of mushrooms, black olives, bell peppers, onions, artichoke hearts, and fresh tomatoes. ";
var hawaiian = "Overloaded with juicy pineapple, smoked bacon, sliced ham, roasted red peppers, provolone cheese, and mozzarella cheese on a cheesy Parmesan crust.";

var meatLovers = "Loads of pepperoni, savory Italian sausage, smoked bacon, hamburger, mushrooms, and extra cheese.";
var theWorks = "An irresistible combination of pepperoni, ham, spicy Italian sausage, fresh-sliced onions and green peppers, gourmet baby portabella mushrooms, and ripe black olives.";
var fourCheese = "Thin-crust pizza with a four-cheese blend of mozzarella, Parmesan, Romano, and Asiago, along with our special seasoning.";